/**
 * 
 */
package com.zx.util;

/**
 * @author Administrator
 *项目中相关常量在此类中声明
 */
public class ConstantUtil {

	public static final String SESSION_USER = "session_user";
}
